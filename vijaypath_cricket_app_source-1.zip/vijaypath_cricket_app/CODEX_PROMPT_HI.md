# Codex के लिए निर्देश

इस repository को पूरा, सुरक्षित और buildable Flutter Android app बनाओ: “विजयपथ क्रिकेट एकेडमी”.

1. पहले Flutter project की स्थिति और installed SDK जांचो। यदि SDK उपलब्ध है, `flutter pub get`, analyzer और tests चलाओ; build errors ठीक करो।
2. Firebase FlutterFire config (`firebase_options.dart`) को सही तरह integrate करो। Firebase credentials कभी hardcode या commit न करो।
3. Firebase Auth login/logout, role-aware routing और trusted admin provisioning बनाओ। कोई user अपना role या academyId स्वयं नहीं बदल सके।
4. `academySettings/main` से academy name, logoUrl, primaryColor, contactNumber, announcementText, bannerUrl और monthlyFee live bind करो।
5. CRUD screens बनाओ: players, batches, enrollments, attendance, feePayments, announcements, performanceReports और gallery। Age group filters U-12/U-16/Open हों।
6. Role policy: admin सब manage करे; coach सिर्फ assigned batches के खिलाड़ी/attendance/reports संभाले; player सिर्फ अपनी profile, attendance, reports और fee records पढ़े।
7. Firestore queries में academyId filters, pagination, loading/error/empty states और indexes शामिल करो।
8. Fees में payment provider confirmation के बिना payment को paid न मानो। कोई secrets app में न रखो।
9. `firebase/firestore.rules` का audit करो, create/update/delete paths अलग करो, cross-academy access बंद करो और Emulator tests जोड़ो।
10. Logo/banner upload Firebase Storage से करो; upload के बाद URL Firestore में save करो। Hex color को ThemeData Color में convert करो।
11. Hindi-first responsive Material 3 UI, accessible forms और input validation बनाओ।
12. `flutter analyze`, tests और उपलब्ध होने पर `flutter build apk --release` चलाओ। यदि build environment या Firebase configuration अनुपलब्ध है, स्पष्ट रूप से बताओ कि क्या नहीं चल सका; fake success या fake APK न बनाओ।
13. अंत में changed files, setup steps, test/build results और APK का वास्तविक path बताओ।
