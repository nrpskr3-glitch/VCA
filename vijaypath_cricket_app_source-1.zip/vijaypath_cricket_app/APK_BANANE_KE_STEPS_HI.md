# विजयपथ क्रिकेट एकेडमी APK बनाने के आसान चरण

**ज़रूरी बात:** इस ZIP में अभी तैयार APK नहीं है। इस वातावरण में Flutter/Android SDK और इंटरनेट उपलब्ध नहीं हैं, इसलिए यहीं APK compile नहीं हो सका। इस प्रोजेक्ट में GitHub Actions workflow जोड़ा गया है, जो GitHub पर अपलोड करने के बाद APK बना सकता है।

## मोबाइल से APK बनवाने का तरीका
1. GitHub पर लॉगिन/साइन अप करें: https://github.com
2. नया repository बनाएँ, नाम रखें `vijaypath-cricket-academy` और उसे **Private** रखना चाहें तो रख सकते हैं।
3. इस ZIP को अपने मोबाइल/कंप्यूटर पर Extract करें। Extract की हुई फ़ोल्डर की सभी फ़ाइलें (छिपा हुआ `.github` फ़ोल्डर भी) repository में upload करें। अगर मोबाइल पर `.github` फ़ोल्डर नहीं दिखता, तो किसी कंप्यूटर/ऐसे फ़ाइल मैनेजर का उपयोग करें जो hidden files दिखाता हो।
4. GitHub repository में **Actions** टैब खोलें। पहली बार workflow के उपयोग के लिए GitHub से अनुमति/enable करने को कहा जा सकता है।
5. **Build Vijaypath Android APK** workflow चुनें और **Run workflow** दबाएँ।
6. रन पूरा होने तक प्रतीक्षा करें। हरा टिक आने पर उसी workflow run को खोलें। नीचे **Artifacts** में `vijaypath-cricket-academy-apk` डाउनलोड करें।
7. डाउनलोड की ZIP को Extract करें। अंदर `app-release.apk` मिलेगा। उसे Android फोन में खोलकर इंस्टॉल करें। फोन पूछे तो केवल अपनी डाउनलोड की हुई फ़ाइल के लिए इंस्टॉल की अनुमति दें।

## सीमाएँ
- यह APK फिलहाल शुरुआती ऐप/डेमो का build होगा; Firebase credentials और database setup किए बिना live data सेव होना सुनिश्चित नहीं है।
- यह production-ready release नहीं है। खिलाड़ियों, फीस, attendance और login को वास्तविक उपयोग में लेने से पहले Firebase configure करना और ऐप को टेस्ट करना ज़रूरी है।
