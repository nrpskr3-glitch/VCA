import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Before running, configure Firebase with `flutterfire configure` and add
// generated firebase_options.dart, then initialize using DefaultFirebaseOptions.
// This starter intentionally shows a preview dashboard until Firebase is configured.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (_) {
    // Allows UI preview before Firebase platform configuration is added.
  }
  runApp(const AcademyApp());
}

class AcademyApp extends StatelessWidget {
  const AcademyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'विजयपथ क्रिकेट एकेडमी',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B45)),
        scaffoldBackgroundColor: const Color(0xFFF6F8F6),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF176B45), foregroundColor: Colors.white),
      ),
      home: const AcademyHome(),
    );
  }
}

class AcademyHome extends StatefulWidget {
  const AcademyHome({super.key});
  @override
  State<AcademyHome> createState() => _AcademyHomeState();
}

class _AcademyHomeState extends State<AcademyHome> {
  int tab = 0;
  String academyName = 'विजयपथ क्रिकेट एकेडमी';
  String announcement = 'अकादमी की घोषणा यहाँ दिखाई जाएगी।';
  int activePlayers = 0;
  double monthlyFees = 0;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('academySettings').doc('main').get();
      if (!doc.exists || !mounted) return;
      final data = doc.data()!;
      setState(() {
        academyName = (data['name'] as String?) ?? academyName;
        announcement = (data['announcementText'] as String?) ?? announcement;
      });
      final players = await FirebaseFirestore.instance.collection('players')
          .where('academyId', isEqualTo: data['academyId']).where('isActive', isEqualTo: true).get();
      final now = DateTime.now();
      final start = DateTime(now.year, now.month);
      final end = DateTime(now.year, now.month + 1);
      final payments = await FirebaseFirestore.instance.collection('feePayments')
          .where('academyId', isEqualTo: data['academyId'])
          .where('status', isEqualTo: 'paid')
          .where('paidAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
          .where('paidAt', isLessThan: Timestamp.fromDate(end)).get();
      if (!mounted) return;
      setState(() {
        activePlayers = players.size;
        monthlyFees = payments.docs.fold<double>(0, (sum, d) => sum + ((d.data()['amount'] as num?)?.toDouble() ?? 0));
      });
    } catch (_) {
      // Firebase configuration/rules may not be set up yet; preview remains usable.
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _dashboard(),
      _collectionPage('खिलाड़ी और बैच', 'players', Icons.groups_rounded),
      _collectionPage('उपस्थिति', 'attendance', Icons.fact_check_rounded),
      _collectionPage('फीस', 'feePayments', Icons.currency_rupee_rounded),
      _settings(),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(academyName, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
        IconButton(onPressed: _loadSettings, icon: const Icon(Icons.refresh), tooltip: 'Refresh')
      ]),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'डैशबोर्ड'),
        NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'खिलाड़ी'),
        NavigationDestination(icon: Icon(Icons.fact_check_outlined), selectedIcon: Icon(Icons.fact_check), label: 'हाज़िरी'),
        NavigationDestination(icon: Icon(Icons.currency_rupee), label: 'फीस'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'सेटिंग्स'),
      ]),
    );
  }

  Widget _dashboard() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFF176B45), borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.sports_cricket, color: Colors.white, size: 42), SizedBox(height: 12),
      Text('खेलें • सीखें • आगे बढ़ें', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
      Text('Cricket Academy Management', style: TextStyle(color: Colors.white70)),
    ])),
    const SizedBox(height: 16),
    Row(children: [Expanded(child: _stat('सक्रिय खिलाड़ी', '$activePlayers', Icons.groups)), const SizedBox(width: 12), Expanded(child: _stat('इस माह फीस', '₹${monthlyFees.toStringAsFixed(0)}', Icons.currency_rupee))]),
    const SizedBox(height: 12),
    Row(children: [Expanded(child: _actionCard('उपस्थिति दर्ज करें', Icons.fact_check, () => setState(() => tab = 2))), const SizedBox(width: 12), Expanded(child: _actionCard('फीस रिकॉर्ड', Icons.receipt_long, () => setState(() => tab = 3)))]),
    const SizedBox(height: 20),
    Card(child: ListTile(leading: const Icon(Icons.campaign, color: Color(0xFF176B45)), title: const Text('अकादमी घोषणा'), subtitle: Text(announcement))),
    const SizedBox(height: 8),
    const Text('नोट: वास्तविक डेटा देखने के लिए Firebase कॉन्फ़िगरेशन और Security Rules सेट करें.', style: TextStyle(color: Colors.black54)),
  ]);

  Widget _stat(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF176B45), size: 28), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(title, style: const TextStyle(color: Colors.black54))])));
  Widget _actionCard(String title, IconData icon, VoidCallback onTap) => Card(child: InkWell(borderRadius: BorderRadius.circular(12), onTap: onTap, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Icon(icon, color: const Color(0xFF176B45), size: 30), const SizedBox(height: 8), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))]))));

  Widget _collectionPage(String title, String collection, IconData icon) => FutureBuilder<QuerySnapshot<Map<String, dynamic>>>(
    future: _fetchCollection(collection),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('$title\nFirebase कनेक्शन या permissions जाँचें.\n${snapshot.error}', textAlign: TextAlign.center)));
      final docs = snapshot.data?.docs ?? [];
      return ListView(padding: const EdgeInsets.all(16), children: [
        Text(title, style: Theme.of(context).textTheme.headlineSmall), const SizedBox(height: 12),
        if (docs.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(24), child: Text('अभी कोई रिकॉर्ड नहीं है। Firebase से डेटा जोड़ने के बाद यहाँ दिखाई देगा.'))),
        ...docs.map((d) => Card(child: ListTile(leading: Icon(icon, color: const Color(0xFF176B45)), title: Text((d.data()['fullName'] ?? d.data()['title'] ?? d.data()['playerId'] ?? 'रिकॉर्ड').toString()), subtitle: Text(d.data()['status']?.toString() ?? d.data()['ageGroup']?.toString() ?? d.id)))),
      ]);
    });

  Future<QuerySnapshot<Map<String, dynamic>>> _fetchCollection(String name) async {
    final settings = await FirebaseFirestore.instance.collection('academySettings').doc('main').get();
    final id = settings.data()?['academyId'] ?? 'vijaypath';
    return FirebaseFirestore.instance.collection(name).where('academyId', isEqualTo: id).limit(100).get();
  }

  final _nameController = TextEditingController(text: 'विजयपथ क्रिकेट एकेडमी');
  final _phoneController = TextEditingController();
  final _feeController = TextEditingController(text: '2000');
  final _announcementController = TextEditingController();

  Widget _settings() => ListView(padding: const EdgeInsets.all(16), children: [
    Text('Academy Settings', style: Theme.of(context).textTheme.headlineSmall), const SizedBox(height: 16),
    TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'अकादमी का नाम', border: OutlineInputBorder())), const SizedBox(height: 12),
    TextField(controller: _phoneController, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'संपर्क नंबर', border: OutlineInputBorder())), const SizedBox(height: 12),
    TextField(controller: _feeController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'मासिक फीस (₹)', border: OutlineInputBorder())), const SizedBox(height: 12),
    TextField(controller: _announcementController, maxLines: 3, decoration: const InputDecoration(labelText: 'घोषणा', border: OutlineInputBorder())), const SizedBox(height: 16),
    FilledButton.icon(onPressed: _saveSettings, icon: const Icon(Icons.save), label: const Text('सेटिंग्स सेव करें')),
    const SizedBox(height: 12), const Text('लोगो अपलोड और थीम कलर picker को Firebase Storage तथा academySettings के साथ जोड़ना अगला setup चरण है.', style: TextStyle(color: Colors.black54)),
  ]);

  Future<void> _saveSettings() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) { _message('सेटिंग्स सेव करने के लिए Admin लॉगिन और Firebase configuration आवश्यक है.'); return; }
      await FirebaseFirestore.instance.collection('academySettings').doc('main').set({
        'academyId': 'vijaypath',
        'name': _nameController.text.trim().isEmpty ? academyName : _nameController.text.trim(),
        'contactNumber': _phoneController.text.trim(),
        'monthlyFee': double.tryParse(_feeController.text.trim()) ?? 2000,
        'announcementText': _announcementController.text.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (!mounted) return;
      setState(() { academyName = _nameController.text.trim().isEmpty ? academyName : _nameController.text.trim(); announcement = _announcementController.text.trim(); });
      _message('सेटिंग्स सेव हो गईं.');
    } catch (e) { _message('सेव नहीं हुआ: $e'); }
  }

  void _message(String text) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }

  @override
  void dispose() {
    _nameController.dispose(); _phoneController.dispose(); _feeController.dispose(); _announcementController.dispose();
    super.dispose();
  }
}
