# विजयपथ क्रिकेट एकेडमी — Flutter + Firebase Starter

यह शुरुआती Flutter Android source project है; यह पहले से बना हुआ APK नहीं है। Firebase project credentials और Android build environment की जरूरत होगी।

## आवश्यकताएँ
- Flutter SDK (stable)
- Android Studio / Android SDK
- Firebase project
- FlutterFire CLI

## Build के चरण
1. इस folder में जाएँ।
2. `flutter pub get`
3. `dart pub global activate flutterfire_cli`
4. `flutterfire configure` चलाएँ और Android Firebase app चुनें।
5. `lib/main.dart` में `firebase_options.dart` import करके `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)` से initialize करें (वर्तमान starter में default initialize है; FlutterFire-generated options से बदलना बेहतर है)।
6. Firebase Authentication में Email/Password enable करें।
7. Firestore और Storage बनाकर rules review/test करें।
8. `flutter run` से device पर जाँचें।
9. Release APK: `flutter build apk --release`
10. APK सामान्यतः `build/app/outputs/flutter-apk/app-release.apk` पर होगा।

## शुरुआती स्क्रीन
- Dashboard: active players, current-month verified fees, announcements
- Players, Attendance, Fees: शुरुआती collection-list views
- Settings: academy name, phone, monthly fee, announcement form

## अभी बाकी जरूरी काम
- Firebase project-specific setup और admin provisioning
- Role-aware routing / login UI
- Players और batches के create/edit/delete forms
- Attendance marking workflow और duplicate prevention
- Fee verification/payment integration
- Logo upload, dynamic theme color picker, banner upload
- पूर्ण Security Rules validation और Emulator tests

`firebase/firestore.rules` एक शुरुआती template है; launch से पहले security review और tests अनिवार्य हैं।
